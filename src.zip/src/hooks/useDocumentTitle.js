import { useEffect } from 'react';
export function useDocumentTitle(title) {
  useEffect(() => { document.title = title ? `${title} | Bineesh Madavath` : 'Bineesh Madavath | Product Design Lead'; }, [title]);
}
